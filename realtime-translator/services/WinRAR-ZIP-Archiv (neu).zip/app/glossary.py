import csv
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple


@dataclass(frozen=True)
class Term:
    src_lang: str
    tgt_lang: str
    src_term: str
    tgt_term: str
    mode: str          # "protect" oder "force"
    priority: int


def load_terms(csv_path: Path) -> List[Term]:
    terms: List[Term] = []
    with csv_path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            terms.append(
                Term(
                    src_lang=row["src_lang"].strip(),
                    tgt_lang=row["tgt_lang"].strip(),
                    src_term=row["src_term"].strip(),
                    tgt_term=row["tgt_term"].strip(),
                    mode=row["mode"].strip().lower(),
                    priority=int(row.get("priority", "0")),
                )
            )
    return terms


def _make_placeholder(i: int) -> str:
    # Robust gegen MT-Veränderungen, keine Sonderzeichen wie '_' die manche MT zerlegen
    return f"ZXQTERM{i:04d}ZXQ"


def apply_glossary(
    text: str, terms: List[Term], src_lang: str, tgt_lang: str
) -> Tuple[str, Dict[str, str], Dict[str, str]]:
    """
    Replaces glossary terms in source text with stable placeholders.

    Returns:
      protected_text: text with placeholders
      protect_map: placeholder -> term to restore (usually tgt_term, e.g. ETCS)
      force_map: placeholder -> forced target term (tgt_term, e.g. Stellwerk)
    """
    candidates = [
        t for perfection in [terms]
        for t in perfection
        if t.src_lang == src_lang and t.tgt_lang == tgt_lang and t.src_term and t.tgt_term
    ]

    # High priority first, then longer phrases first
    candidates.sort(key=lambda t: (t.priority, len(t.src_term)), reverse=True)

    out = text
    protect_map: Dict[str, str] = {}
    force_map: Dict[str, str] = {}

    placeholder_idx = 1

    for t in candidates:
        # Match whole phrase (not inside words). Allow flexible whitespace inside multiword terms.
        parts = [re.escape(p) for p in t.src_term.split()]
        pat = r"(?<!\w)" + r"\s+".join(parts) + r"(?!\w)"
        rx = re.compile(pat, flags=re.IGNORECASE)

        if not rx.search(out):
            continue

        # Instead of placeholders (which MT can drop/duplicate), insert target term directly.
        out = rx.sub(t.tgt_term, out)

        # Track which target terms were injected so post-edit can protect/inflect them.
        if t.mode == "protect":
            protect_map[t.tgt_term] = t.tgt_term
        else:
            force_map[t.tgt_term] = t.tgt_term


    return out, protect_map, force_map


def restore_glossary(text: str, protect_map: Dict[str, str], force_map: Dict[str, str]) -> str:
    out = text

    # Replace longer placeholders first (defensive)
    for ph, val in sorted({**protect_map, **force_map}.items(), key=lambda x: len(x[0]), reverse=True):
        out = out.replace(ph, val)

    # whitespace cleanup
    out = re.sub(r"\s{2,}", " ", out).strip()
    return out

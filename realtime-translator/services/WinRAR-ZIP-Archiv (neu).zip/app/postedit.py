import re
from typing import Iterable, List, Optional, Tuple

import language_tool_python


def _find_term_spans(text: str, terms: Iterable[str]) -> List[Tuple[int, int]]:
    spans: List[Tuple[int, int]] = []
    for term in sorted({t for t in terms if t and t.strip()}, key=len, reverse=True):
        pat = re.compile(rf"(?<!\w){re.escape(term)}(?!\w)")
        for m in pat.finditer(text):
            spans.append((m.start(), m.end()))
    return spans


def _overlaps(a0: int, a1: int, b0: int, b1: int) -> bool:
    return not (a1 <= b0 or b1 <= a0)


def _allow_term_edit_de(original: str, replacement: str) -> bool:
    """
    Allow only safe inflection-like edits for German glossary terms.

    Allowed:
      - Genitive: TERM -> TERM+s/es (but not if TERM endswith 'en')
      - Dative plural: TERM -> TERM+n (Gleise -> Gleisen)

    Block:
      - Gleisarbeiten -> Gleisarbeitens
      - any stem-changing edits
    """
    o = original.strip()
    r = replacement.strip()
    if not o or not r:
        return False

    if not r.startswith(o) or len(r) <= len(o):
        return False

    suffix = r[len(o):]
    if not re.fullmatch(r"[A-Za-zÄÖÜäöüß]{1,3}", suffix):
        return False

    o_l = o.lower()
    s_l = suffix.lower()

    if s_l == "n":
        if o_l.endswith(("n", "s", "ß", "x", "z")):
            return False
        return True

    if s_l in {"s", "es"}:
        if o_l.endswith("en"):
            return False
        return True

    return False


def _term_pattern_with_suffix_de(term: str) -> str:
    """
    Regex pattern that matches the term allowing safe suffixes on the last token.
    Allowed suffixes: n, s, es
    """
    parts = term.split()
    if not parts:
        return re.escape(term)

    last = re.escape(parts[-1])
    prefix = r"\s+".join(re.escape(p) for p in parts[:-1])

    last_pat = rf"{last}(?:n|s|es)?"
    if prefix:
        return rf"{prefix}\s+{last_pat}"
    return last_pat


def _allow_phrase_edit_with_term_de(term_in_text: str, replacement: str) -> bool:
    """
    Allow LT phrase replacements if the replacement still contains the glossary term,
    optionally with a safe suffix (n, s, es) on the last token.

    Blocks adding s/es to terms ending with 'en' (Gleisarbeiten -> Gleisarbeitens).
    """
    term_in_text = term_in_text.strip()
    replacement = replacement.strip()
    if not term_in_text or not replacement:
        return False

    pat = re.compile(rf"(?<!\w){_term_pattern_with_suffix_de(term_in_text)}(?!\w)", re.IGNORECASE)
    if not pat.search(replacement):
        return False

    if term_in_text.lower().endswith("en"):
        last = term_in_text.split()[-1]
        bad_pat = re.compile(rf"(?<!\w){re.escape(last)}(?:s|es)(?!\w)", re.IGNORECASE)
        if bad_pat.search(replacement):
            return False

    return True


def _apply_matches_with_term_policy(
    text: str,
    matches,
    protected_spans: List[Tuple[int, int]],
    inflectable_spans: List[Tuple[int, int]],
    lang: str,
) -> str:
    out = text
    matches_sorted = sorted(matches, key=lambda m: m.offset, reverse=True)

    for m in matches_sorted:
        replacements = getattr(m, "replacements", None)
        if not replacements:
            continue
        replacement = replacements[0]

        start = getattr(m, "offset")
        length = getattr(m, "error_length", None)
        if length is None:
            length = getattr(m, "errorLength")
        end = start + length

        # Protected spans: never edit
        if any(_overlaps(start, end, s0, s1) for (s0, s1) in protected_spans):
            continue

        overlaps_inflectable = [(s0, s1) for (s0, s1) in inflectable_spans if _overlaps(start, end, s0, s1)]
        if overlaps_inflectable:
            if not lang.lower().startswith("de"):
                continue

            s0, s1 = overlaps_inflectable[0]
            term_text = text[s0:s1]

            if start == s0 and end == s1:
                if not _allow_term_edit_de(term_text, replacement):
                    continue
            else:
                if not _allow_phrase_edit_with_term_de(term_text, replacement):
                    continue

        out = out[:start] + replacement + out[end:]

    out = re.sub(r"\s{2,}", " ", out).strip()
    return out


class _GermanInflector:
    """
    Deterministic post-edit for German around glossary terms.
    These are generic grammar patterns applied only when the involved noun is in
    inflectable_terms.

    Fixes:
      - 'des TERM' -> genitive form (TERM+s/es) for non-plural-like terms
      - 'des TERM' -> 'der TERM' for plural-like terms ending with 'en'
      - 'an der TERM' -> 'an den TERMn' (plural dative) for terms where TERM+n is sensible
      - 'an dem TERM' -> 'an den TERMn' (common MT error when plural intended)
    """

    @staticmethod
    def _fallback_genitive(head: str) -> str:
        low = head.lower()
        if low.endswith(("s", "ß", "x", "z")):
            return head + "es"
        return head + "s"

    @staticmethod
    def _is_plural_like_en(term: str) -> bool:
        # conservative: only treat ...en as plural-like
        return term.strip().lower().endswith("en")

    @staticmethod
    def _can_add_dative_n(term: str) -> bool:
        # Avoid adding -n to words already ending in n/s/ß/x/z
        low = term.strip().lower()
        return not low.endswith(("n", "s", "ß", "x", "z"))

    def _genitive_term(self, term: str) -> str:
        parts = term.split()
        if not parts:
            return term
        head = parts[-1]
        gen_head = self._fallback_genitive(head)
        return " ".join(parts[:-1] + [gen_head])

    def _dative_plural_term(self, term: str) -> str:
        parts = term.split()
        if not parts:
            return term
        head = parts[-1]
        if self._can_add_dative_n(head):
            head = head + "n"
        return " ".join(parts[:-1] + [head])

    def apply(self, text: str, inflectable_terms: Iterable[str]) -> str:
        out = text
        terms = sorted({t for t in inflectable_terms if t and t.strip()}, key=len, reverse=True)

        for base in terms:
            # 1) Genitive with "des"
            if self._is_plural_like_en(base):
                out = re.sub(
                    rf"\bdes\s+{re.escape(base)}\b",
                    f"der {base}",
                    out,
                    flags=re.IGNORECASE,
                )
            else:
                gen = self._genitive_term(base)
                out = re.sub(
                    rf"\bdes\s+{re.escape(base)}\b",
                    f"des {gen}",
                    out,
                    flags=re.IGNORECASE,
                )

            # 2) Dative plural after "an der/an dem"
            # Only apply for terms where adding -n is sensible (Gleise -> Gleisen)
            dpl = self._dative_plural_term(base)

            # "an der Gleise" -> "an den Gleisen"
            out = re.sub(
                rf"\ban\s+der\s+{re.escape(base)}\b",
                f"an den {dpl}",
                out,
                flags=re.IGNORECASE,
            )

            # "an dem Gleise" -> "an den Gleisen" (MT sometimes uses dem incorrectly)
            out = re.sub(
                rf"\ban\s+dem\s+{re.escape(base)}\b",
                f"an den {dpl}",
                out,
                flags=re.IGNORECASE,
            )

        out = re.sub(r"\s{2,}", " ", out).strip()
        return out


class PostEditor:
    def __init__(self, lang: str = "de-DE", mode: str = "fast") -> None:
        self.lang = lang
        self.mode = mode.lower()
        self._tool: Optional[language_tool_python.LanguageTool] = None
        self._de_inflector = _GermanInflector() if lang.lower().startswith("de") else None

    def start(self) -> None:
        if self.mode == "full" and self._tool is None:
            self._tool = language_tool_python.LanguageTool(self.lang)

    def correct(
        self,
        text: str,
        protected_terms: Optional[Iterable[str]] = None,
        inflectable_terms: Optional[Iterable[str]] = None,
    ) -> str:
        if not text:
            return text

        protected_terms = protected_terms or []
        inflectable_terms = inflectable_terms or []

        out = text

        # FAST deterministic layer (always)
        if self._de_inflector is not None and inflectable_terms:
            out = self._de_inflector.apply(out, inflectable_terms)

        if self.mode != "full":
            return out

        # FULL: LanguageTool + policy
        self.start()
        assert self._tool is not None

        protected_spans = _find_term_spans(out, protected_terms)
        inflectable_spans = _find_term_spans(out, inflectable_terms)

        matches = self._tool.check(out)
        out = _apply_matches_with_term_policy(
            out,
            matches,
            protected_spans=protected_spans,
            inflectable_spans=inflectable_spans,
            lang=self.lang,
        )

        # Apply deterministic layer again in case LT changed the surrounding tokens
        if self._de_inflector is not None and inflectable_terms:
            out = self._de_inflector.apply(out, inflectable_terms)

        return out

    def close(self) -> None:
        if self._tool is not None:
            self._tool.close()
            self._tool = None

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

import argostranslate.translate
import requests


@dataclass
class TranslationConfig:
    backend: str = "argos"  # "argos" oder "modernmt"
    src_lang: str = "en"
    tgt_lang: str = "de"
    modernmt_url: str = "http://127.0.0.1:8045/translate"
    timeout_s: float = 10.0


class Translator:
    def __init__(self, cfg: TranslationConfig):
        self.cfg = cfg

    def translate(self, text: str, src: Optional[str] = None, tgt: Optional[str] = None, context: str = "") -> str:
        src = src or self.cfg.src_lang
        tgt = tgt or self.cfg.tgt_lang

        if self.cfg.backend == "argos":
            return argostranslate.translate.translate(text, src, tgt)

        if self.cfg.backend == "modernmt":
            return self._translate_modernmt(text, src, tgt, context)

        raise ValueError(f"Unknown backend: {self.cfg.backend}")

    def _translate_modernmt(self, text: str, src: str, tgt: str, context: str) -> str:
        params = {
            "q": text,
            "source": src,
            "target": tgt,
        }
        if context:
            params["context"] = context

        r = requests.get(self.cfg.modernmt_url, params=params, timeout=self.cfg.timeout_s)
        r.raise_for_status()
        data = r.json()

        if "data" in data and "translation" in data["data"]:
            return data["data"]["translation"]

        if "translation" in data:
            return data["translation"]

        raise RuntimeError(f"Unexpected ModernMT response: {data}")

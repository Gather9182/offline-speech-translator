@echo off
setlocal
cd /d "%~dp0"

echo [Launcher] Working dir:
cd
echo.

if not exist ".\.venv\Scripts\activate.bat" (
  color 0C
  echo ERROR: venv not found. Run setup.cmd first.
  pause
  exit /b 1
)

call ".\.venv\Scripts\activate.bat"
echo [Launcher] Python:
where python
python --version
echo.

echo [Launcher] Starting app...
python realtime_translate.py
echo.

echo Exit code: %ERRORLEVEL%
pause

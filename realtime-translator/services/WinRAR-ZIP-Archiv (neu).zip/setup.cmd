@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo === Realtime Translator Setup (Windows) ===
echo Working dir: %cd%
echo.

REM --- Detect Python (prefer py launcher) ---
set "PYEXE="

where py >nul 2>nul
if %ERRORLEVEL%==0 (
  set "PYEXE=py"
) else (
  where python >nul 2>nul
  if %ERRORLEVEL%==0 (
    set "PYEXE=python"
  )
)

if "%PYEXE%"=="" (
  echo ERROR: Python not found in PATH.
  echo Install Python 3.11 (recommended) and try again.
  echo If winget is available you can run:
  echo   winget install -e --id Python.Python.3.11
  pause
  exit /b 1
)

echo Using: %PYEXE%
%PYEXE% --version
echo.

REM --- Create venv if missing ---
if not exist ".venv\Scripts\activate.bat" (
  echo Creating virtual environment...
  %PYEXE% -m venv .venv
  if %ERRORLEVEL% NEQ 0 (
    echo ERROR: venv creation failed.
    pause
    exit /b 1
  )
)

call ".venv\Scripts\activate.bat"
if %ERRORLEVEL% NEQ 0 (
  echo ERROR: Could not activate venv.
  pause
  exit /b 1
)

echo.
echo Upgrading pip...
python -m pip install --upgrade pip

echo.
echo Installing dependencies...
if exist "requirements-lock.txt" (
  python -m pip install -r requirements-lock.txt
) else (
  python -m pip install -r requirements.txt
)

if %ERRORLEVEL% NEQ 0 (
  echo ERROR: pip install failed.
  pause
  exit /b 1
)

echo.
echo Checking basic imports...
python -c "import numpy, sounddevice, webrtcvad; print('imports ok')"
if %ERRORLEVEL% NEQ 0 (
  echo ERROR: Import check failed.
  pause
  exit /b 1
)

echo.
echo Checking config.json...
if not exist "config.json" (
  echo ERROR: config.json not found next to this script.
  pause
  exit /b 1
)

echo.
echo Setup finished.
echo Next:
echo - Ensure Piper voice model exists at path configured in config.json
echo - Ensure Argos models are installed (run scripts if needed)
echo - Start with run.cmd
echo.
pause

@echo off
setlocal

set "ROOT=%~dp0"
set "CFG=%ROOT%config.json"
set "PY=%ROOT%scripts\config_editor.py"

REM Ensure sounddevice is available (install if missing)
python -c "import sounddevice" >nul 2>nul
if errorlevel 1 (
  echo Installing Python dependency: sounddevice
  python -m pip install --upgrade pip >nul 2>nul
  python -m pip install sounddevice
)

python "%PY%" "%CFG%"

endlocal

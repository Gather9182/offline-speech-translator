import json
import locale
import os
import queue
import re
import subprocess
import sys
import time
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

import numpy as np
import sounddevice as sd
import webrtcvad
from faster_whisper import WhisperModel

from app.translation import Translator, TranslationConfig
from app.glossary import load_terms, apply_glossary, restore_glossary


# Korrekturen für bekannte STT-Fehlhörer
STT_CORRECTIONS = {
    "upp": "ÖBB",
    "u p p": "ÖBB",
    "oebb": "ÖBB",
    "obb": "ÖBB",
}


def normalize_stt_text(text: str) -> str:
    t = re.sub(r"\s+", " ", text).strip()
    for wrong, right in STT_CORRECTIONS.items():
        pattern = re.compile(r"\b" + re.escape(wrong) + r"\b", re.IGNORECASE)
        t = pattern.sub(right, t)
    return t


def load_config() -> Dict[str, Any]:
    cfg_path = os.environ.get("OEBB_CONFIG")
    if cfg_path:
        path = Path(cfg_path)
    else:
        path = Path(__file__).with_name("config.json")

    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")

    with path.open("r", encoding="utf-8") as f:
        cfg = json.load(f)

    return cfg


def piper_tts_to_wav(text: str, model_path: Path, out_wav: Path) -> None:
    enc = locale.getpreferredencoding(False)
    tmp_txt = out_wav.with_suffix(".txt")
    tmp_txt.write_text(text + "\n", encoding=enc, errors="strict")

    # bevorzugt: file input/output
    cmd1 = [
        "piper",
        "--model", str(model_path),
        "--input-file", str(tmp_txt),
        "--output-file", str(out_wav),
    ]
    p = subprocess.run(
        cmd1,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding=enc,
        errors="replace",
    )
    if p.returncode == 0:
        return

    # fallback: stdin
    cmd2 = ["piper", "-m", str(model_path), "-f", str(out_wav)]
    p2 = subprocess.run(
        cmd2,
        input=text + "\n",
        text=True,
        encoding=enc,
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if p2.returncode != 0:
        raise RuntimeError((p.stderr or "") + "\n" + (p2.stderr or ""))


def play_wav(path: Path, device_index: int) -> None:
    with wave.open(str(path), "rb") as wf:
        channels = wf.getnchannels()
        sr = wf.getframerate()
        sampwidth = wf.getsampwidth()
        if sampwidth != 2:
            raise RuntimeError(f"Expected 16-bit WAV, got sampwidth={sampwidth}")
        data = wf.readframes(wf.getnframes())

    audio = np.frombuffer(data, dtype=np.int16)
    if channels > 1:
        audio = audio.reshape(-1, channels)
    audio_f32 = audio.astype(np.float32) / 32768.0

    sd.play(audio_f32, samplerate=sr, device=device_index)
    sd.wait()


@dataclass
class AudioFrame:
    pcm16: bytes
    timestamp: float


def int16_bytes_from_float32(x: np.ndarray) -> bytes:
    x = np.clip(x, -1.0, 1.0)
    return (x * 32767.0).astype(np.int16).tobytes()


def main() -> int:
    cfg = load_config()

    sample_rate = int(cfg["audio"]["sample_rate"])
    mic_device_index = int(cfg["audio"]["mic_device_index"])
    out_device_index = int(cfg["audio"]["out_device_index"])

    stt_model_name = cfg["stt"]["model"]
    stt_device = cfg["stt"]["device"]
    stt_compute_type = cfg["stt"]["compute_type"]
    stt_language = cfg["stt"]["language"]

    vad_mode = int(cfg["vad"]["mode"])
    frame_ms = int(cfg["vad"]["frame_ms"])
    min_speech_ms = int(cfg["vad"]["min_speech_ms"])
    end_silence_ms = int(cfg["vad"]["end_silence_ms"])

    blocksize = int(sample_rate * frame_ms / 1000)

    terms_csv = Path(cfg["rag"]["terms_csv"])
    tts_voice_model = Path(cfg["tts"]["voice_model"])
    tts_tmp_wav = Path(cfg["tts"]["tmp_wav"])

    if not terms_csv.exists():
        raise FileNotFoundError(f"Glossary CSV not found: {terms_csv}")
    if not tts_voice_model.exists():
        raise FileNotFoundError(f"TTS voice model not found: {tts_voice_model}")

    translator = Translator(
    TranslationConfig(
        backend=cfg["mt"].get("backend", "argos"),
        src_lang=cfg["mt"]["src_lang"],
        tgt_lang=cfg["mt"]["tgt_lang"],
        modernmt_url=cfg["mt"].get("modernmt_url", "http://127.0.0.1:8045/translate"),
    )
)

    
    
    terms = load_terms(terms_csv)

    print("Loading Whisper model (first run downloads model if missing)...")
    model = WhisperModel(stt_model_name, device=stt_device, compute_type=stt_compute_type)
    print("Ready. Speak into the microphone. Ctrl+C to stop.")

    vad = webrtcvad.Vad(vad_mode)
    q: "queue.Queue[AudioFrame]" = queue.Queue()

    def callback(indata, frames, time_info, status):
        if status:
            print(status, file=sys.stderr)
        mono = indata[:, 0].copy()
        pcm16 = int16_bytes_from_float32(mono)
        q.put(AudioFrame(pcm16=pcm16, timestamp=time.time()))

    voiced_bytes = bytearray()
    speech_ms = 0
    silence_ms = 0
    in_speech = False

    with sd.InputStream(
        samplerate=sample_rate,
        channels=1,
        dtype="float32",
        blocksize=blocksize,
        device=mic_device_index,
        callback=callback,
    ):
        try:
            while True:
                frame = q.get()
                is_speech = vad.is_speech(frame.pcm16, sample_rate)

                if is_speech:
                    if not in_speech:
                        in_speech = True
                        voiced_bytes.clear()
                        speech_ms = 0
                        silence_ms = 0
                        print("\n[Speech start]")
                    voiced_bytes.extend(frame.pcm16)
                    speech_ms += frame_ms
                    silence_ms = 0
                else:
                    if in_speech:
                        silence_ms += frame_ms
                        voiced_bytes.extend(frame.pcm16)

                        if silence_ms >= end_silence_ms and speech_ms >= min_speech_ms:
                            audio_i16 = np.frombuffer(bytes(voiced_bytes), dtype=np.int16)
                            audio_f32 = audio_i16.astype(np.float32) / 32768.0

                            print("[Transcribing...]")
                            segments, _info = model.transcribe(
                                audio_f32,
                                language=stt_language,
                                vad_filter=False,
                                beam_size=1,
                                temperature=0.0,
                            )

                            text = "".join(seg.text for seg in segments).strip()
                            text = normalize_stt_text(text)

                            if text:
                                print(f"[{stt_language}] {text}")

                                protected, protect_map, force_map = apply_glossary(
                                    text, terms, cfg["mt"]["src_lang"], cfg["mt"]["tgt_lang"]
                                )

                                translated = translator.translate(
                                    protected, cfg["mt"]["src_lang"], cfg["mt"]["tgt_lang"]
                                )

                                final_text = restore_glossary(translated, protect_map, force_map)
                                print(f"[{cfg['mt']['tgt_lang']}] {final_text}")

                                print("[tts] speaking...")
                                piper_tts_to_wav(final_text, tts_voice_model, tts_tmp_wav)
                                play_wav(tts_tmp_wav, out_device_index)
                            else:
                                print("[no text]")

                            in_speech = False
                            voiced_bytes.clear()
                            speech_ms = 0
                            silence_ms = 0
                            print("[Speech end]")

                if in_speech and speech_ms < min_speech_ms and silence_ms >= end_silence_ms:
                    in_speech = False
                    voiced_bytes.clear()
                    speech_ms = 0
                    silence_ms = 0

        except KeyboardInterrupt:
            print("\nStopping.")
            return 0


if __name__ == "__main__":
    raise SystemExit(main())

import queue
import sys
import time
import re
import locale
from dataclasses import dataclass
import subprocess
import wave
from pathlib import Path

import numpy as np
import sounddevice as sd
import webrtcvad
from faster_whisper import WhisperModel
from app.translation import Translator, TranslationConfig
from app.glossary import load_terms, apply_glossary, restore_glossary

SAMPLE_RATE = 16000
CHANNELS = 1

MIC_DEVICE_INDEX = 1  # dein Mikrofon (MME)
VAD_MODE = 2          # 0..3 (3 = aggressiv)
FRAME_MS = 30         # webrtcvad braucht 10/20/30 ms
BLOCKSIZE = int(SAMPLE_RATE * FRAME_MS / 1000)

OUT_DEVICE_INDEX = 3  # Lautsprecher (Logitech PRO X Wireless, MME)
TTS_VOICE_MODEL = Path(r"C:\Entwicklung\oebb-projekt\realtime-translator\services\tts\voices\de_DE-thorsten-medium.onnx")
TTS_TMP_WAV = Path(r"C:\Entwicklung\oebb-projekt\realtime-translator\services\orchestrator\tts_out.wav")



# Segment-Policy (Latenz vs. Stabilität)
MIN_SPEECH_MS = 300         # mindestens so viel Sprache, bevor wir transkribieren
END_SILENCE_MS = 600        # so viel Stille beendet ein Segment

# Hot-Fix für Umlaut in ÖBB
STT_CORRECTIONS = {
    "upp": "ÖBB",
    "u p p": "ÖBB",
    "oebb": "ÖBB",
    "oe bb": "ÖBB",
    "obb": "ÖBB",
}

def normalize_stt_text(text: str) -> str:
    t = text
    # Normalisiere mehrfach spaces
    t = re.sub(r"\s+", " ", t).strip()
    low = t.lower()

    # Ersetze ganze Wörter oder Wortgruppen (case-insensitive)
    for wrong, right in STT_CORRECTIONS.items():
        pattern = re.compile(r"\b" + re.escape(wrong) + r"\b", re.IGNORECASE)
        t = pattern.sub(right, t)

    return t
    
@dataclass
class AudioFrame:
    pcm16: bytes
    timestamp: float


def int16_bytes_from_float32(x: np.ndarray) -> bytes:
    x = np.clip(x, -1.0, 1.0)
    return (x * 32767.0).astype(np.int16).tobytes()
    
def piper_tts_to_wav(text: str, model_path: Path, out_wav: Path) -> None:
    enc = locale.getpreferredencoding(False)  # typischerweise cp1252 auf DE-Windows
    tmp_txt = out_wav.with_suffix(".txt")
    tmp_txt.write_text(text + "\n", encoding=enc, errors="strict")

    # Versuch 1: neuer CLI Stil mit input/output file
    cmd1 = [
        "piper",
        "--model", str(model_path),
        "--input-file", str(tmp_txt),
        "--output-file", str(out_wav),
    ]
    p = subprocess.run(cmd1, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding=enc, errors="replace")
    if p.returncode == 0:
        return

    # Versuch 2: dein bisheriger Stil (stdin), aber in Windows-Encoding
    cmd2 = ["piper", "-m", str(model_path), "-f", str(out_wav)]
    p2 = subprocess.run(
        cmd2,
        input=text + "\n",
        text=True,
        encoding=enc,
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if p2.returncode != 0:
        raise RuntimeError(p.stderr + "\n" + p2.stderr)



def play_wav(path: Path, device_index: int) -> None:
    with wave.open(str(path), "rb") as wf:
        channels = wf.getnchannels()
        sr = wf.getframerate()
        sampwidth = wf.getsampwidth()
        if sampwidth != 2:
            raise RuntimeError(f"Expected 16-bit WAV, got sampwidth={sampwidth}")
        data = wf.readframes(wf.getnframes())

    audio = np.frombuffer(data, dtype=np.int16)
    if channels > 1:
        audio = audio.reshape(-1, channels)
    audio_f32 = audio.astype(np.float32) / 32768.0

    sd.play(audio_f32, samplerate=sr, device=device_index)
    sd.wait()


def main() -> int:
    print("Loading Whisper model (first run downloads model if missing)...")
    # Für Geschwindigkeit: "base" oder "small"
    # device="cuda" falls NVIDIA+CUDA später; jetzt CPU:
    model = WhisperModel("small", device="cpu", compute_type="int8")
    
    # Mit Argos Translate und Terminologie verbinden.
    translator = Translator(TranslationConfig(src_lang="en", tgt_lang="de"))
    terms = load_terms(Path(r"C:\Entwicklung\oebb-projekt\realtime-translator\rag\terminology\rail_terms.csv"))
    
    if not TTS_VOICE_MODEL.exists():
        raise FileNotFoundError(f"TTS voice model not found: {TTS_VOICE_MODEL}")
    

    print("Ready. Speak into the microphone. Ctrl+C to stop.")

    vad = webrtcvad.Vad(VAD_MODE)
    q: "queue.Queue[AudioFrame]" = queue.Queue()

    def callback(indata, frames, time_info, status):
        if status:
            print(status, file=sys.stderr)
        # indata: float32 [-1..1], shape (frames, channels)
        mono = indata[:, 0].copy()
        pcm16 = int16_bytes_from_float32(mono)
        q.put(AudioFrame(pcm16=pcm16, timestamp=time.time()))

    # State für Segmentierung
    voiced_bytes = bytearray()
    speech_ms = 0
    silence_ms = 0
    in_speech = False

    with sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=CHANNELS,
        dtype="float32",
        blocksize=BLOCKSIZE,
        device=MIC_DEVICE_INDEX,
        callback=callback,
    ):
        try:
            while True:
                frame = q.get()
                is_speech = vad.is_speech(frame.pcm16, SAMPLE_RATE)

                if is_speech:
                    if not in_speech:
                        in_speech = True
                        voiced_bytes.clear()
                        speech_ms = 0
                        silence_ms = 0
                        print("\n[Speech start]")
                    voiced_bytes.extend(frame.pcm16)
                    speech_ms += FRAME_MS
                    silence_ms = 0
                else:
                    if in_speech:
                        silence_ms += FRAME_MS
                        # Wir hängen noch etwas Stille an, hilft oft am Segmentende
                        voiced_bytes.extend(frame.pcm16)

                        if silence_ms >= END_SILENCE_MS and speech_ms >= MIN_SPEECH_MS:
                            # Segment finalisieren
                            audio_i16 = np.frombuffer(bytes(voiced_bytes), dtype=np.int16)
                            audio_f32 = audio_i16.astype(np.float32) / 32768.0

                            print("[Transcribing...]")
                            segments, info = model.transcribe(
                                audio_f32,
                                language="en",       # auto; später fix: "cs"/"it"/"hu"
                                vad_filter=False,    # wir machen VAD selbst
                                beam_size=1,
                                temperature=0.0,
                            )

                            text = "".join(seg.text for seg in segments).strip()
                            text = normalize_stt_text(text)

                            if text:
                                # STT Ausgabe
                                print(f"[en] {text}")

                                # Glossar anwenden (en->de)
                                protected, protect_map, force_map = apply_glossary(text, terms, "en", "de")

                                # Übersetzen
                                translated = translator.translate(protected, "en", "de")

                                # Glossar wiederherstellen
                                final_de = restore_glossary(translated, protect_map, force_map)

                                # DE Ausgabe
                                print(f"[de] {final_de}")
                                
                                # DE Sprachausgabe
                                print("[tts] speaking...")
                                piper_tts_to_wav(final_de, TTS_VOICE_MODEL, TTS_TMP_WAV)
                                play_wav(TTS_TMP_WAV, OUT_DEVICE_INDEX)
                            else:
                                print("[no text]")


                            in_speech = False
                            voiced_bytes.clear()
                            speech_ms = 0
                            silence_ms = 0
                            print("[Speech end]")

                # Wenn Segment zu kurz war, nicht transkribieren, sondern verwerfen
                if in_speech and speech_ms < MIN_SPEECH_MS and silence_ms >= END_SILENCE_MS:
                    in_speech = False
                    voiced_bytes.clear()
                    speech_ms = 0
                    silence_ms = 0

        except KeyboardInterrupt:
            print("\nStopping.")
            return 0


if __name__ == "__main__":
    raise SystemExit(main())

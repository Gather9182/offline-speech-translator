"""
BACKUP OHNE POST-EDIT LAYER
realtime_translate.py

End-to-end prototype for near real-time speech translation (offline-first):

Audio In (microphone)
  -> VAD (webrtcvad) to segment speech
  -> STT (faster-whisper) to transcribe speech to text
  -> Glossary layer (placeholder protection/forced terms)
  -> MT (Argos by default, optionally ModernMT via HTTP)
  -> Glossary restore
  -> TTS (Piper) to synthesize translated text
Audio Out (speaker/headset)

Design goals:
- Offline development on Windows (microphone/speaker devices via sounddevice)
- Config-driven for later deployment (Azure-friendly)
- Modular translation backends (Argos now, ModernMT later)
- Terminology handling via glossary layer (RAG/term protection foundation)
"""

import json
import locale
import os
import queue
import re
import subprocess
import sys
import time
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

import numpy as np
import sounddevice as sd
import webrtcvad
from faster_whisper import WhisperModel

from app.translation import Translator, TranslationConfig
from app.glossary import load_terms, apply_glossary, restore_glossary


# -----------------------------------------------------------------------------
# STT post-processing
# -----------------------------------------------------------------------------
# Simple correction map to fix predictable ASR mis-hearings.
# This is intentionally small, deterministic and serves as a small Hot-fix (no ML).
# Extend as needed for railway-specific abbreviations, station names, etc.
STT_CORRECTIONS = {
    "upp": "ÖBB",
    "u p p": "ÖBB",
    "oebb": "ÖBB",
    "obb": "ÖBB",
}


def normalize_stt_text(text: str) -> str:
    """
    Normalize and correct STT output.

    - Collapses repeated whitespace (STT sometimes emits odd spacing)
    - Applies case-insensitive word-boundary replacements for known mis-hearings

    Args:
        text: Raw transcription from STT.

    Returns:
        Cleaned text suitable for glossary + translation.
    """
    t = re.sub(r"\s+", " ", text).strip()
    for wrong, right in STT_CORRECTIONS.items():
        pattern = re.compile(r"\b" + re.escape(wrong) + r"\b", re.IGNORECASE)
        t = pattern.sub(right, t)
    return t


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------
def load_config() -> Dict[str, Any]:
    """
    Load runtime configuration.

    Uses environment variable OEBB_CONFIG if set. Otherwise reads config.json
    located next to this script.

    Returns:
        Parsed configuration dictionary.

    Raises:
        FileNotFoundError: If the config file is missing.
        json.JSONDecodeError: If config JSON is invalid.
    """
    cfg_path = os.environ.get("OEBB_CONFIG")
    if cfg_path:
        path = Path(cfg_path)
    else:
        path = Path(__file__).with_name("config.json")

    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")

    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


# -----------------------------------------------------------------------------
# TTS helpers (Piper)
# -----------------------------------------------------------------------------
def piper_tts_to_wav(text: str, model_path: Path, out_wav: Path) -> None:
    """
    Synthesize text to a WAV file using Piper.

    Why file-based input:
      On Windows, piping Unicode via stdin can produce broken umlauts depending
      on codepage/console encoding. Writing a temporary text file using the
      system preferred encoding is the most reliable approach.

    Strategy:
      1) Prefer Piper's --input-file/--output-file mode (robust)
      2) Fallback to stdin mode if needed

    Args:
        text: Text to synthesize.
        model_path: Path to Piper ONNX voice model.
        out_wav: Output WAV file path.

    Raises:
        RuntimeError: If Piper fails in both modes.
    """
    enc = locale.getpreferredencoding(False)

    # Write TTS text to a sidecar file next to the wav. Keep file lifetime simple.
    tmp_txt = out_wav.with_suffix(".txt")
    tmp_txt.write_text(text + "\n", encoding=enc, errors="strict")

    # Preferred mode: explicit input/output files
    cmd1 = [
        "piper",
        "--model",
        str(model_path),
        "--input-file",
        str(tmp_txt),
        "--output-file",
        str(out_wav),
    ]
    p = subprocess.run(
        cmd1,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding=enc,
        errors="replace",
    )
    if p.returncode == 0:
        return

    # Fallback: stdin -> wav
    cmd2 = ["piper", "-m", str(model_path), "-f", str(out_wav)]
    p2 = subprocess.run(
        cmd2,
        input=text + "\n",
        text=True,
        encoding=enc,
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if p2.returncode != 0:
        raise RuntimeError((p.stderr or "") + "\n" + (p2.stderr or ""))


def play_wav(path: Path, device_index: int) -> None:
    """
    Play a WAV file using sounddevice.

    Piper typically produces 16-bit PCM WAV. We decode into float32 [-1, 1]
    for playback via sounddevice.

    Args:
        path: Path to WAV file.
        device_index: sounddevice output device index.

    Raises:
        RuntimeError: If the WAV format is unexpected.
    """
    with wave.open(str(path), "rb") as wf:
        channels = wf.getnchannels()
        sr = wf.getframerate()
        sampwidth = wf.getsampwidth()
        if sampwidth != 2:
            raise RuntimeError(f"Expected 16-bit WAV, got sampwidth={sampwidth}")
        data = wf.readframes(wf.getnframes())

    audio = np.frombuffer(data, dtype=np.int16)
    if channels > 1:
        audio = audio.reshape(-1, channels)
    audio_f32 = audio.astype(np.float32) / 32768.0

    sd.play(audio_f32, samplerate=sr, device=device_index)
    sd.wait()


# -----------------------------------------------------------------------------
# Audio capture structures
# -----------------------------------------------------------------------------
@dataclass
class AudioFrame:
    """
    A single chunk of audio captured from the microphone.

    pcm16: raw 16-bit PCM mono frame bytes (required by webrtcvad)
    timestamp: capture timestamp (not currently used, but useful for debugging)
    """
    pcm16: bytes
    timestamp: float


def int16_bytes_from_float32(x: np.ndarray) -> bytes:
    """
    Convert float32 audio samples in [-1, 1] to 16-bit PCM bytes.

    Args:
        x: Mono float32 numpy array.

    Returns:
        Byte string of int16 PCM values.
    """
    x = np.clip(x, -1.0, 1.0)
    return (x * 32767.0).astype(np.int16).tobytes()


# -----------------------------------------------------------------------------
# Main pipeline
# -----------------------------------------------------------------------------
def main() -> int:
    """
    Run the real-time translation loop.

    Pipeline:
      - audio input stream callback pushes frames into a Queue
      - main thread reads frames, performs VAD to decide segment boundaries
      - when segment ends, run STT -> glossary -> MT -> glossary restore -> TTS

    Returns:
        Process exit code (0 for clean shutdown).
    """
    cfg = load_config()

    # --- Audio config ---
    sample_rate = int(cfg["audio"]["sample_rate"])
    mic_device_index = int(cfg["audio"]["mic_device_index"])
    out_device_index = int(cfg["audio"]["out_device_index"])

    # --- STT config ---
    stt_model_name = cfg["stt"]["model"]
    stt_device = cfg["stt"]["device"]
    stt_compute_type = cfg["stt"]["compute_type"]
    stt_language = cfg["stt"]["language"]  # fixed language for deterministic STT

    # --- VAD config ---
    vad_mode = int(cfg["vad"]["mode"])  # 0..3 (3 = most aggressive)
    frame_ms = int(cfg["vad"]["frame_ms"])  # must be 10/20/30ms for webrtcvad
    min_speech_ms = int(cfg["vad"]["min_speech_ms"])  # minimum speech before transcribing
    end_silence_ms = int(cfg["vad"]["end_silence_ms"])  # silence to close segment

    # Derived constants
    blocksize = int(sample_rate * frame_ms / 1000)

    # --- Paths ---
    terms_csv = Path(cfg["rag"]["terms_csv"])
    tts_voice_model = Path(cfg["tts"]["voice_model"])
    tts_tmp_wav = Path(cfg["tts"]["tmp_wav"])

    # Validate critical files early (fail fast)
    if not terms_csv.exists():
        raise FileNotFoundError(f"Glossary CSV not found: {terms_csv}")
    if not tts_voice_model.exists():
        raise FileNotFoundError(f"TTS voice model not found: {tts_voice_model}")

    # --- MT backend ---
    # Translator is backend-agnostic (Argos offline, ModernMT via HTTP).
    translator = Translator(
        TranslationConfig(
            backend=cfg["mt"].get("backend", "argos"),
            src_lang=cfg["mt"]["src_lang"],
            tgt_lang=cfg["mt"]["tgt_lang"],
            modernmt_url=cfg["mt"].get("modernmt_url", "http://127.0.0.1:8045/translate"),
        )
    )

    # Load glossary/terminology rules (CSV)
    terms = load_terms(terms_csv)

    # Load STT model once at startup (expensive). Reuse for all segments.
    print("Loading Whisper model (first run downloads model if missing)...")
    model = WhisperModel(stt_model_name, device=stt_device, compute_type=stt_compute_type)
    print("Ready. Speak into the microphone. Ctrl+C to stop.")

    # Initialize VAD and audio frame queue
    vad = webrtcvad.Vad(vad_mode)
    q: "queue.Queue[AudioFrame]" = queue.Queue()

    def callback(indata, frames, time_info, status):
        """
        sounddevice InputStream callback.

        This must be fast and non-blocking:
          - Convert to int16 PCM bytes required by webrtcvad
          - Enqueue for processing in the main thread
        """
        if status:
            print(status, file=sys.stderr)

        # indata: float32 [-1..1], shape (frames, channels)
        mono = indata[:, 0].copy()
        pcm16 = int16_bytes_from_float32(mono)
        q.put(AudioFrame(pcm16=pcm16, timestamp=time.time()))

    # Segmentation state
    voiced_bytes = bytearray()
    speech_ms = 0
    silence_ms = 0
    in_speech = False

    # Start microphone stream
    with sd.InputStream(
        samplerate=sample_rate,
        channels=1,
        dtype="float32",
        blocksize=blocksize,
        device=mic_device_index,
        callback=callback,
    ):
        try:
            while True:
                frame = q.get()
                is_speech = vad.is_speech(frame.pcm16, sample_rate)

                if is_speech:
                    # Enter speech mode and start collecting bytes
                    if not in_speech:
                        in_speech = True
                        voiced_bytes.clear()
                        speech_ms = 0
                        silence_ms = 0
                        print("\n[Speech started. App is listening...]")

                    voiced_bytes.extend(frame.pcm16)
                    speech_ms += frame_ms
                    silence_ms = 0
                else:
                    if in_speech:
                        # Track silence while in a speech segment
                        silence_ms += frame_ms
                        voiced_bytes.extend(frame.pcm16)

                        # Segment ends when we have enough speech + enough trailing silence
                        if silence_ms >= end_silence_ms and speech_ms >= min_speech_ms:
                            # Convert accumulated bytes to float32 for Whisper
                            audio_i16 = np.frombuffer(bytes(voiced_bytes), dtype=np.int16)
                            audio_f32 = audio_i16.astype(np.float32) / 32768.0

                            # STT
                            print("[Transcribing and translating...]")
                            t_stt0 = time.perf_counter()
                            segments, _info = model.transcribe(
                                audio_f32,
                                language=stt_language,
                                vad_filter=False,  # we do our own VAD
                                beam_size=1,       # speed-oriented
                                temperature=0.0,   # deterministic
                            )
                            t_stt1 = time.perf_counter()


                            # Combine segments into a single line of text
                            text = "".join(seg.text for seg in segments).strip()
                            text = normalize_stt_text(text)

                            if text:
                                # Total timing for the whole pipeline (until playback starts)
                                t_total0 = time.perf_counter()

                                print("[Transcribed output:]")
                                print(f"--[{stt_language}] {text}")

                                # Glossary (pre-translation)
                                protected, protect_map, force_map = apply_glossary(
                                    text, terms, cfg["mt"]["src_lang"], cfg["mt"]["tgt_lang"]
                                )

                                # MT timing
                                t_mt0 = time.perf_counter()
                                translated = translator.translate(
                                    protected, cfg["mt"]["src_lang"], cfg["mt"]["tgt_lang"]
                                )
                                t_mt1 = time.perf_counter()

                                # Glossary restore
                                final_text = restore_glossary(translated, protect_map, force_map)
                                print(f"--[{cfg['mt']['tgt_lang']}] {final_text}")

                                # TTS (wav generation) timing
                                t_tts0 = time.perf_counter()
                                piper_tts_to_wav(final_text, tts_voice_model, tts_tmp_wav)
                                t_tts1 = time.perf_counter()

                                # Report timings BEFORE playback
                                t_total1 = time.perf_counter()
                                mt_ms = (t_mt1 - t_mt0) * 1000.0
                                tts_ms = (t_tts1 - t_tts0) * 1000.0
                                total_ms = (t_total1 - t_total0) * 1000.0
                                stt_ms = (t_stt1 - t_stt0) * 1000.0
                                
                                print(f"[Timing] STT: {stt_ms:.0f} ms | MT: {mt_ms:.0f} ms | TTS: {tts_ms:.0f} ms | TOTAL(before play): {total_ms:.0f} ms")


                                # Playback
                                print("[TTS] playing...")
                                play_wav(tts_tmp_wav, out_device_index)
                            else:
                                print("[no text]")


                            # Reset segment state
                            in_speech = False
                            voiced_bytes.clear()
                            speech_ms = 0
                            silence_ms = 0
                            print("[Speech ended]")

                # Guard: if we ended up with too-short speech (e.g., a click),
                # discard after enough silence to avoid tiny STT calls.
                if in_speech and speech_ms < min_speech_ms and silence_ms >= end_silence_ms:
                    in_speech = False
                    voiced_bytes.clear()
                    speech_ms = 0
                    silence_ms = 0

        except KeyboardInterrupt:
            print("\nStopping.")
            return 0


if __name__ == "__main__":
    raise SystemExit(main())
